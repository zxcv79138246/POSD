#include "Shapes.h"

using namespace std;

Shapes::Shapes()
{
    //ctor
}

Shapes::~Shapes()
{
    //dtor
}
