#include "Shape.h"

using namespace std;

Shape::Shape()
{
    //ctor
}

Shape::~Shape()
{
    //dtor
}
