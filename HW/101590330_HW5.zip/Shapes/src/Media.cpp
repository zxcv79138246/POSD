#include "Media.h"

Media::Media()
{
    //ctor
}

Media::~Media()
{
    //dtor
}
