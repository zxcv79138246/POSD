#include "MediaBuilder.h"

MediaBuilder::MediaBuilder()
{
    //ctor
}

MediaBuilder::~MediaBuilder()
{
    //dtor
}
