#include "Document.h"

Document::Document()
{
    //ctor
}

Document::~Document()
{
    //dtor
}
