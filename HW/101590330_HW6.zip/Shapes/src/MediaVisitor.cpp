#include "MediaVisitor.h"

MediaVisitor::MediaVisitor()
{
    //ctor
}

MediaVisitor::~MediaVisitor()
{
    //dtor
}
